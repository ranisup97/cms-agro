<?php defined('BASEPATH') OR exit("No direct script access allowed");
$route['maps-restaurant/dels']          = "maps_restaurant/remove";
$route['maps-restaurant/view']          = "maps_restaurant/view_detail";
$route['maps-restaurant/forms/save']    = "maps_restaurant/forms_save";
$route['maps-restaurant/forms']         = "maps_restaurant/forms";
$route['maps-restaurant']               = "maps_restaurant";
// $route['maps-restaurant-certificate/(:any)']        = './../assets/restaurant/';