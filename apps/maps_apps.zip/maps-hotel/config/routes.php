<?php defined('BASEPATH') OR exit("No direct script access allowed");
$route['maps-hotel/dels']           = "maps_hotel/remove";
$route['maps-hotel/view']           = "maps_hotel/view_detail";
$route['maps-hotel/forms/save']     = "maps_hotel/forms_save";
$route['maps-hotel/forms']          = "maps_hotel/forms";
$route['maps-hotel']                = "maps_hotel";