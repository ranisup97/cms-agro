<?php defined('BASEPATH') OR exit("No direct script access allowed");
$route['maps-company/dels']             = "maps_company/remove";
$route['maps-company/view']             = "maps_company/view_detail";
$route['maps-company/forms/save']       = "maps_company/forms_save";
$route['maps-company/forms']            = "maps_company/forms";
$route['maps-company']                  = "maps_company";