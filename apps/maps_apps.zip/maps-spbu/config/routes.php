<?php defined('BASEPATH') OR exit("No direct script access allowed");
$route['maps-spbu/dels']            = "maps_spbu/remove";
$route['maps-spbu/view']            = "maps_spbu/view_detail";
$route['maps-spbu/forms/save']      = "maps_spbu/forms_save";
$route['maps-spbu/forms']           = "maps_spbu/forms";
$route['maps-spbu']                 = "maps_spbu";